package com.example.demotask.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.simranjeettask.R

class MyAdapter(private val context: Context) :
    RecyclerView.Adapter<MyAdapter.ViewHolder>() {
    // ViewHolder represents each item in the RecyclerView
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    }

    // Create new views (invoked by the layout manager)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false)
        return ViewHolder(view)
    }

    // Replace the contents of a view (invoked by the layout manager)
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
// Update selected item index

    }

    // Return the size of your dataset (invoked by the layout manager)
    override fun getItemCount(): Int {
        return 4
    }

}
