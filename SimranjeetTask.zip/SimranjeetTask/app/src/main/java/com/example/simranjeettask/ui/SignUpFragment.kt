package com.example.simranjeettask.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.collection.ArrayMap
import androidx.core.app.ActivityCompat.finishAffinity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.simranjeettask.R
import com.example.simranjeettask.databinding.FragmentLoginBinding
import com.example.simranjeettask.databinding.FragmentSplashBinding
import com.example.simranjeettask.viewmodel.LoginViewModel
import com.example.simranjeettask.webservices.Status
import kotlinx.coroutines.launch

class SignUpFragment : Fragment(),View.OnClickListener {
   lateinit var binding:FragmentSplashBinding
    private  lateinit var viewModel: LoginViewModel
    private var maps = ArrayMap<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding=FragmentSplashBinding.inflate(layoutInflater)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        initListener()

        initObserver()
        setupBackpress()

    }
    fun initObserver() {
        lifecycleScope.launch {
            viewModel!!.getSignUp.collect{
                when(it.status){
                    Status.LOADING->{
                    }
                    Status.SUCCESS->{
                        if(it.data!!.success == true){
                            Toast.makeText(requireContext(),it.data.message.toString(), Toast.LENGTH_SHORT).show()
                            replaceFragments(LoginFragment())

                        }
                        else{
                            if(it.data.success ==false){
                                Toast.makeText(requireContext(), it.data.message.toString(), Toast.LENGTH_SHORT).show()
                            }
                            else{
                                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                            }

                        }
                    }
                    else -> {
                        if(Status.NONE!=it.status){
                            if (it.message?.contains("html") == true) {

                                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                            }

                            if (it.message == "HTTP 401 Unauthorized"){
                                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                            }else{
//                                Toast.makeText(requireContext(), it.data?.message, Toast.LENGTH_SHORT).show()
                            }

                        }
                    }
                }
            }
        }
    }

    fun initListener() {
        binding.tvSignUp.setOnClickListener(this)
        binding.textlogin.setOnClickListener(this)
    }
    private fun replaceFragments(fragment: Fragment){
        parentFragmentManager.beginTransaction().setReorderingAllowed(true).replace(R.id.fragmentContainer, fragment,"1").addToBackStack("hi").commit()
    }

    private fun setupBackpress() {
        val dispatcher = requireActivity().onBackPressedDispatcher
        val callback: OnBackPressedCallback =
            object : OnBackPressedCallback(true /* enabled by default */) {
                override fun handleOnBackPressed() {
                    finishAffinity(requireActivity())

                }
            }

        dispatcher.addCallback(requireActivity(), callback)
    }

    override fun onClick(p0: View?) {
        when(p0?.id){
            R.id.textlogin->{
                replaceFragments(LoginFragment())

            }
            R.id.tvSignUp->{
                callApi()
            }

        }
    }

    fun callApi(){
        if(binding.fullname.text.isNullOrEmpty()){
            Toast.makeText(requireContext(), "Enter name", Toast.LENGTH_SHORT).show()
        }
        if(binding.etEmail.text.isNullOrEmpty()){
            Toast.makeText(requireContext(), "Enter email", Toast.LENGTH_SHORT).show()
        }
        if(binding.number.text.isNullOrEmpty()){
            Toast.makeText(requireContext(), "Enter number", Toast.LENGTH_SHORT).show()
        }
        if(binding.etPassword.text.isNullOrEmpty()){
            Toast.makeText(requireContext(), "Enter Password", Toast.LENGTH_SHORT).show()
        }
        if(binding.etConfirmPassword.text.isNullOrEmpty()){
            Toast.makeText(requireContext(), "Enter Confirm Password", Toast.LENGTH_SHORT).show()
        }
        else{
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString()
            val number = binding.number.text.toString()
            val name = binding.fullname.text.toString()
            val ctpassword = binding.etConfirmPassword.text.toString()
            if(password!=ctpassword){
                Toast.makeText(requireContext(), "Password must be same", Toast.LENGTH_SHORT).show()
            }
            else if(!binding.cbBox.isChecked){
                Toast.makeText(requireContext(), "Accept terms and conditions", Toast.LENGTH_SHORT).show()
            }
            else{
                if (email.isNullOrEmpty() || password.isNotEmpty() ||number.isNotEmpty() || name.isNotEmpty()){
                    maps.clear()
                    maps["email"] = email
                    maps["password"] = password
                    maps["phone_number"] = number
                    maps["name"] = name
                    maps["device_token"] = "j3lj9sjdljljsdkjgnncknv"
                    maps["device_type"] = "0"
                    viewModel!!.SignUp(maps)
                }
                else{
                    Toast.makeText(requireContext(), "Something went wrong!", Toast.LENGTH_SHORT).show()
                }
            }
            //TODO


        }

    }
}