package com.example.simranjeettask.model

class category : ArrayList<categoryItem>()

data class categoryItem(
    val created_at: String?=null,
    val id: Int?=null,
    val name: String?=null,
    val restaurant: List<Restaurant>?=null,
    val status: Int?=null,
    val updated_at: String?=null
)

data class Restaurant(
    val address: String,
    val category_id: Int,
    val created_at: String,
    val filename: String,
    val id: Int,
    val image_url: String,
    val name: String,
    val path: String,
    val phone_number: String,
    val status: Int,
    val updated_at: String
)