package com.example.simranjeettask.webservices

import retrofit2.http.DELETE

object
UrlHelper {
     const val base_url="https://dev.bosselt.com/backend-assessment/public/"
     //EndPoints
     const val USER_SIGNUP="api/register"
     const val USER_LOGIN="api/login"
     const val CATEGORY="categories"

}