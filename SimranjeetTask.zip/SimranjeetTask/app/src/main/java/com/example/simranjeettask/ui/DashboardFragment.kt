package com.example.simranjeettask.ui

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.demotask.adapter.MyAdapter
import com.example.demotask.adapter.MyAdapter2
import com.example.demotask.adapter.MyAdapter3
import com.example.simranjeettask.R
import com.example.simranjeettask.databinding.FragmentDashboardBinding
import com.example.simranjeettask.model.Restaurant
import com.example.simranjeettask.viewmodel.LoginViewModel
import com.example.simranjeettask.webservices.Status
import com.google.android.material.carousel.CarouselSnapHelper
import kotlinx.coroutines.launch

class DashboardFragment : Fragment(),View.OnClickListener {
    lateinit var binding: FragmentDashboardBinding
    private  lateinit var viewModel: LoginViewModel
    private var data: ArrayList<Restaurant>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       binding=FragmentDashboardBinding.inflate(layoutInflater)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[LoginViewModel::class.java]
        viewModel.getCategory()
        initObserver()
       val adapter= MyAdapter(requireContext(),)
        binding.rvMexican.adapter=adapter
        val adapter2= MyAdapter2(requireContext())
        binding.rvAsian.adapter=adapter2
        val adapter3= MyAdapter3(requireContext());
        binding.italian.adapter=adapter3
    }
     fun initObserver() {
        lifecycleScope.launch {
            viewModel.category.collect{
                when(it.status){
                    Status.LOADING->{
                    }
                    Status.SUCCESS->{
                        if(!it.data!!.isEmpty()){
                            Toast.makeText(requireContext(), it.data.get(0).name.toString(), Toast.LENGTH_SHORT).show()
                            val restaurantList = it.data[0].restaurant
                            if (restaurantList != null && restaurantList.isNotEmpty()) {
                                val restaurant = restaurantList[0]
                                data!!.add(restaurant) // Add the single Restaurant object

                            }
                        }


                    }
                    else -> {
                        if(Status.NONE!=it.status){
                            if (it.message?.contains("html") == true) {

                                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                            }

                            if (it.message == "HTTP 401 Unauthorized"){
                                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                            }else{
//                                Toast.makeText(requireContext(), it.data?.message, Toast.LENGTH_SHORT).show()
                            }

                        }
                    }


                }
            }
        }


    }
    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }


}